# UAE Smart Services Hub

A polished, mobile-friendly, bilingual (English/Arabic) static website that helps people find official UAE and Abu Dhabi public-service websites.

## What is included
- `index.html` — complete site (HTML, CSS and JavaScript in one file)
- English/Arabic language switch with RTL layout for Arabic
- Search and category filters
- Official service links and clear independent-project disclaimers
- Responsive layout, keyboard focus styles, and reduced-motion support
- No backend, database, account system, payments, or document uploads

## Important before publishing
This is an independent project, not a government website. Do not use UAE government logos, imply endorsement, collect identity documents, or present summaries as official decisions. Verify every URL and the scope of each service before launch. Official sites can change their URLs or requirements.

## Run locally
1. Download and unzip the project.
2. Open `index.html` in a modern browser.
3. Test the search, category filters, English/Arabic switch, and every external link.

No build tools or package installation are required.

## Publish for free with GitHub Pages
1. Create/sign in to a GitHub account at https://github.com/.
2. Create a **public** repository named `uae-smart-services-hub`.
3. Upload `index.html` and `README.md` from this folder.
4. Open the repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then save.
7. Wait for GitHub Pages to publish and open the URL shown in the Pages settings.

Alternative: Vercel can also host a static HTML site. Import the repository and use the default static deployment settings; no framework or build command is needed.

## Before sharing it publicly
- Check official links in both languages and on a phone.
- Have a fluent Arabic speaker review the Arabic wording before treating it as publication-ready.
- Add a contact method and privacy page only if you can maintain them.
- Consider adding a last-verified date for each link and a process to review links regularly.
- Do not add advertising or analytics until you have read the applicable privacy requirements.

## Disclaimer
This site is an independent directory and is not affiliated with, endorsed by, or operated by any UAE government entity. Links are offered for convenience. Always confirm current eligibility, documents, fees, and procedures with the relevant official authority.
