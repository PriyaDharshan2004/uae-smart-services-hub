/* Official destinations catalogue. Review source links periodically. */
window.UAE_HUB_SERVICES = [
  {
    "id": "uae-portal",
    "category": "general",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Government",
    "title": {
      "en": "UAE Government Portal",
      "ar": "بوابة حكومة الإمارات"
    },
    "description": {
      "en": "The official federal gateway for government information, services, policies and guidance.",
      "ar": "البوابة الاتحادية الرسمية للمعلومات والخدمات والسياسات والإرشادات الحكومية."
    },
    "url": "https://u.ae/en/",
    "keywords": "government federal services portal official"
  },
  {
    "id": "service-directory",
    "category": "general",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Government",
    "title": {
      "en": "Federal Services Directory",
      "ar": "دليل الخدمات الاتحادية"
    },
    "description": {
      "en": "Browse federal services by topic, audience and responsible government entity.",
      "ar": "تصفح الخدمات الاتحادية حسب الموضوع والفئة والجهة الحكومية المسؤولة."
    },
    "url": "https://u.ae/en/Services-Directory",
    "keywords": "service directory government services"
  },
  {
    "id": "abu-dhabi-gov",
    "category": "general",
    "authority": "Abu Dhabi",
    "emirate": "Abu Dhabi",
    "audience": "Government",
    "title": {
      "en": "Abu Dhabi Government",
      "ar": "حكومة أبوظبي"
    },
    "description": {
      "en": "Find Abu Dhabi government entities, popular resources and official service channels.",
      "ar": "اعثر على الجهات الحكومية في أبوظبي والموارد الشائعة وقنوات الخدمات الرسمية."
    },
    "url": "https://www.abudhabi.gov.ae/en/",
    "keywords": "abu dhabi government services"
  },
  {
    "id": "tamm",
    "category": "general",
    "authority": "Abu Dhabi",
    "emirate": "Abu Dhabi",
    "audience": "Residents",
    "title": {
      "en": "TAMM — Abu Dhabi Services",
      "ar": "تم — خدمات أبوظبي"
    },
    "description": {
      "en": "Use Abu Dhabi's government service platform for local services and transactions.",
      "ar": "استخدم منصة الخدمات الحكومية في أبوظبي للخدمات والمعاملات المحلية."
    },
    "url": "https://www.tamm.abudhabi/",
    "keywords": "tamm abu dhabi local services"
  },
  {
    "id": "icp",
    "category": "identity",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Residents",
    "title": {
      "en": "ICP — Identity, Visa & Residency",
      "ar": "الهيئة الاتحادية — الهوية والتأشيرات والإقامة"
    },
    "description": {
      "en": "Official identity card, visa, entry-permit and residency services. Check the service requirements on ICP.",
      "ar": "خدمات الهوية والتأشيرات وأذونات الدخول والإقامة الرسمية. تحقق من المتطلبات عبر الهيئة."
    },
    "url": "https://icp.gov.ae/en/",
    "keywords": "emirates id visa residency identity passport entry permit"
  },
  {
    "id": "icp-services",
    "category": "identity",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Residents",
    "title": {
      "en": "ICP Interactive Services",
      "ar": "خدمات الهيئة التفاعلية"
    },
    "description": {
      "en": "Find specific ICP services and filter by customer type, service category and channel.",
      "ar": "اعثر على خدمات الهيئة المحددة وصنفها حسب نوع المتعامل والفئة والقناة."
    },
    "url": "https://icp.gov.ae/en/services/interactive-services/",
    "keywords": "identity services visa residence permits"
  },
  {
    "id": "uae-visa",
    "category": "identity",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Visitors",
    "title": {
      "en": "Visa & Emirates ID Guidance",
      "ar": "إرشادات التأشيرات والهوية الإماراتية"
    },
    "description": {
      "en": "Read UAE Government guidance about visa, entry and Emirates ID topics before applying.",
      "ar": "اقرأ إرشادات حكومة الإمارات حول التأشيرات والدخول والهوية قبل تقديم الطلب."
    },
    "url": "https://u.ae/en/information-and-services/visa-and-emirates-id",
    "keywords": "visa entry tourist visit residence id"
  },
  {
    "id": "mohre",
    "category": "work",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Workers",
    "title": {
      "en": "MOHRE — Labour & Employment",
      "ar": "وزارة الموارد البشرية — العمل والتوظيف"
    },
    "description": {
      "en": "Official labour information, employment services, worker guidance and complaint channels.",
      "ar": "معلومات العمل الرسمية وخدمات التوظيف وإرشادات العمال وقنوات الشكاوى."
    },
    "url": "https://www.mohre.gov.ae/en/home.aspx",
    "keywords": "work job employment salary wages contract labour complaint worker"
  },
  {
    "id": "jobs-guidance",
    "category": "work",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Workers",
    "title": {
      "en": "Working in the UAE",
      "ar": "العمل في الإمارات"
    },
    "description": {
      "en": "Understand official employment guidance, job-search information and workplace rules.",
      "ar": "افهم الإرشادات الرسمية للتوظيف والبحث عن عمل وقواعد مكان العمل."
    },
    "url": "https://u.ae/en/information-and-services/jobs",
    "keywords": "job seeker employment job search contract work"
  },
  {
    "id": "mohap",
    "category": "health",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Residents",
    "title": {
      "en": "MOHAP — Health Services",
      "ar": "وزارة الصحة — الخدمات الصحية"
    },
    "description": {
      "en": "Federal health information, public-health guidance and ministry services.",
      "ar": "المعلومات الصحية الاتحادية وإرشادات الصحة العامة وخدمات الوزارة."
    },
    "url": "https://mohap.gov.ae/",
    "keywords": "health medicine healthcare medical"
  },
  {
    "id": "doh",
    "category": "health",
    "authority": "Abu Dhabi",
    "emirate": "Abu Dhabi",
    "audience": "Residents",
    "title": {
      "en": "Department of Health — Abu Dhabi",
      "ar": "دائرة الصحة — أبوظبي"
    },
    "description": {
      "en": "Official health-sector information, regulation and services in Abu Dhabi.",
      "ar": "المعلومات والتنظيم والخدمات الرسمية للقطاع الصحي في أبوظبي."
    },
    "url": "https://www.doh.gov.ae/",
    "keywords": "abu dhabi health hospital clinic"
  },
  {
    "id": "dha",
    "category": "health",
    "authority": "Dubai",
    "emirate": "Dubai",
    "audience": "Residents",
    "title": {
      "en": "Dubai Health Authority",
      "ar": "هيئة الصحة بدبي"
    },
    "description": {
      "en": "Dubai health-sector information and official healthcare services.",
      "ar": "معلومات القطاع الصحي في دبي وخدمات الرعاية الصحية الرسمية."
    },
    "url": "https://www.dha.gov.ae/",
    "keywords": "dubai health hospital clinic"
  },
  {
    "id": "ehs",
    "category": "health",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Residents",
    "title": {
      "en": "Emirates Health Services",
      "ar": "مؤسسة الإمارات للخدمات الصحية"
    },
    "description": {
      "en": "Find federal health facilities, patient services and healthcare information.",
      "ar": "اعثر على المنشآت الصحية الاتحادية وخدمات المرضى والمعلومات الصحية."
    },
    "url": "https://www.ehs.gov.ae/",
    "keywords": "health clinics hospitals patient"
  },
  {
    "id": "moi",
    "category": "safety",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Residents",
    "title": {
      "en": "Ministry of Interior",
      "ar": "وزارة الداخلية"
    },
    "description": {
      "en": "Access official interior, public-safety, traffic and police-related services.",
      "ar": "الوصول إلى خدمات الداخلية والسلامة العامة والمرور والشرطة الرسمية."
    },
    "url": "https://www.moi.gov.ae/en/",
    "keywords": "police traffic vehicle safety ministry interior"
  },
  {
    "id": "moi-eservices",
    "category": "safety",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Residents",
    "title": {
      "en": "MOI E-Services Directory",
      "ar": "دليل الخدمات الإلكترونية لوزارة الداخلية"
    },
    "description": {
      "en": "Browse Ministry of Interior services, including traffic and public services.",
      "ar": "تصفح خدمات وزارة الداخلية، بما فيها خدمات المرور والخدمات العامة."
    },
    "url": "https://portal.moi.gov.ae/eservices/default.aspx?Culture=en",
    "keywords": "traffic driving licence vehicle police services"
  },
  {
    "id": "abudhabi-police",
    "category": "safety",
    "authority": "Abu Dhabi",
    "emirate": "Abu Dhabi",
    "audience": "Residents",
    "title": {
      "en": "Abu Dhabi Police",
      "ar": "شرطة أبوظبي"
    },
    "description": {
      "en": "Use official Abu Dhabi Police information and digital service channels.",
      "ar": "استخدم معلومات شرطة أبوظبي الرسمية وقنوات الخدمات الرقمية."
    },
    "url": "https://www.adpolice.gov.ae/",
    "keywords": "abu dhabi police traffic safety"
  },
  {
    "id": "admobility",
    "category": "transport",
    "authority": "Abu Dhabi",
    "emirate": "Abu Dhabi",
    "audience": "Residents",
    "title": {
      "en": "Abu Dhabi Mobility",
      "ar": "أبوظبي للتنقل"
    },
    "description": {
      "en": "Find Abu Dhabi public-transport, mobility and transport-service information.",
      "ar": "اعثر على معلومات النقل العام والتنقل وخدمات المواصلات في أبوظبي."
    },
    "url": "https://admobility.gov.ae/",
    "keywords": "bus taxi transport mobility abu dhabi"
  },
  {
    "id": "rta",
    "category": "transport",
    "authority": "Dubai",
    "emirate": "Dubai",
    "audience": "Residents",
    "title": {
      "en": "RTA — Dubai Transport",
      "ar": "هيئة الطرق والمواصلات — دبي"
    },
    "description": {
      "en": "Official Dubai transport, public mobility, driving and vehicle service information.",
      "ar": "المعلومات الرسمية للنقل والتنقل العام والقيادة وخدمات المركبات في دبي."
    },
    "url": "https://www.rta.ae/",
    "keywords": "dubai transport metro nol bus driving licence"
  },
  {
    "id": "dewa",
    "category": "utilities",
    "authority": "Dubai",
    "emirate": "Dubai",
    "audience": "Residents",
    "title": {
      "en": "DEWA — Electricity & Water",
      "ar": "ديوا — الكهرباء والمياه"
    },
    "description": {
      "en": "Official Dubai electricity and water connections, bills and customer services.",
      "ar": "خدمات توصيل الكهرباء والمياه والفواتير والمتعاملين الرسمية في دبي."
    },
    "url": "https://www.dewa.gov.ae/",
    "keywords": "electricity water bill connection utilities dubai"
  },
  {
    "id": "taqa",
    "category": "utilities",
    "authority": "Abu Dhabi",
    "emirate": "Abu Dhabi",
    "audience": "Residents",
    "title": {
      "en": "TAQA Distribution",
      "ar": "طاقة للتوزيع"
    },
    "description": {
      "en": "Electricity and water distribution information and customer services for areas it serves in Abu Dhabi.",
      "ar": "معلومات توزيع الكهرباء والمياه وخدمات المتعاملين للمناطق التي تخدمها في أبوظبي."
    },
    "url": "https://www.taqadistribution.com/",
    "keywords": "abu dhabi electricity water bill utilities"
  },
  {
    "id": "dubai-municipality",
    "category": "housing",
    "authority": "Dubai",
    "emirate": "Dubai",
    "audience": "Residents",
    "title": {
      "en": "Dubai Municipality",
      "ar": "بلدية دبي"
    },
    "description": {
      "en": "Explore Dubai municipal services, public facilities and city information.",
      "ar": "استكشف الخدمات البلدية والمرافق العامة ومعلومات المدينة في دبي."
    },
    "url": "https://www.dm.gov.ae/",
    "keywords": "dubai municipality housing city"
  },
  {
    "id": "dmt",
    "category": "housing",
    "authority": "Abu Dhabi",
    "emirate": "Abu Dhabi",
    "audience": "Residents",
    "title": {
      "en": "Department of Municipalities & Transport",
      "ar": "دائرة البلديات والنقل"
    },
    "description": {
      "en": "Find Abu Dhabi municipal, planning, housing and transport-related information.",
      "ar": "اعثر على المعلومات البلدية والتخطيط والإسكان والنقل ذات الصلة في أبوظبي."
    },
    "url": "https://www.dmt.gov.ae/",
    "keywords": "abu dhabi municipality housing tenancy"
  },
  {
    "id": "dubai-land",
    "category": "housing",
    "authority": "Dubai",
    "emirate": "Dubai",
    "audience": "Residents",
    "title": {
      "en": "Dubai Land Department",
      "ar": "دائرة الأراضي والأملاك في دبي"
    },
    "description": {
      "en": "Official Dubai property, real-estate registration and tenancy-related information.",
      "ar": "المعلومات الرسمية للعقارات والتسجيل العقاري والإيجارات في دبي."
    },
    "url": "https://dubailand.gov.ae/",
    "keywords": "property rent tenancy real estate housing"
  },
  {
    "id": "fta",
    "category": "business",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Businesses",
    "title": {
      "en": "Federal Tax Authority",
      "ar": "الهيئة الاتحادية للضرائب"
    },
    "description": {
      "en": "Official tax information and services, including VAT and corporate tax.",
      "ar": "المعلومات والخدمات الضريبية الرسمية، بما فيها ضريبة القيمة المضافة وضريبة الشركات."
    },
    "url": "https://tax.gov.ae/",
    "keywords": "tax vat corporate tax business"
  },
  {
    "id": "moet",
    "category": "business",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Businesses",
    "title": {
      "en": "Ministry of Economy & Tourism",
      "ar": "وزارة الاقتصاد والسياحة"
    },
    "description": {
      "en": "Official federal information on the economy, business and related services.",
      "ar": "المعلومات الاتحادية الرسمية حول الاقتصاد والأعمال والخدمات ذات الصلة."
    },
    "url": "https://www.moet.gov.ae/",
    "keywords": "business company economy trade"
  },
  {
    "id": "moe",
    "category": "education",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Residents",
    "title": {
      "en": "Ministry of Education",
      "ar": "وزارة التربية والتعليم"
    },
    "description": {
      "en": "Find official education policy, school and learning-related information.",
      "ar": "اعثر على معلومات التعليم والسياسات والمدارس والتعلم الرسمية."
    },
    "url": "https://www.moe.gov.ae/",
    "keywords": "education school university learning"
  },
  {
    "id": "mofa",
    "category": "travel",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Visitors",
    "title": {
      "en": "Ministry of Foreign Affairs",
      "ar": "وزارة الخارجية"
    },
    "description": {
      "en": "Official consular, attestation and foreign-affairs information and services.",
      "ar": "المعلومات والخدمات الرسمية للشؤون القنصلية والتصديقات والخارجية."
    },
    "url": "https://www.mofa.gov.ae/",
    "keywords": "attestation consular travel foreign affairs"
  },
  {
    "id": "uaepass",
    "category": "identity",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Residents",
    "title": {
      "en": "UAE PASS",
      "ar": "الهوية الرقمية UAE PASS"
    },
    "description": {
      "en": "Learn about the UAE's national digital identity and secure access to participating services.",
      "ar": "تعرف على الهوية الرقمية الوطنية في الإمارات والوصول الآمن إلى الخدمات المشاركة."
    },
    "url": "https://uaepass.ae/",
    "keywords": "digital identity login authentication"
  },
  {
    "id": "fta-directory",
    "category": "business",
    "authority": "Federal",
    "emirate": "All",
    "audience": "Businesses",
    "title": {
      "en": "UAE Business & Investment Guidance",
      "ar": "إرشادات الأعمال والاستثمار في الإمارات"
    },
    "description": {
      "en": "Start with official guidance for business setup, licences and investment in the UAE.",
      "ar": "ابدأ بالإرشادات الرسمية لتأسيس الأعمال والتراخيص والاستثمار في الإمارات."
    },
    "url": "https://u.ae/en/information-and-services/business",
    "keywords": "business setup company licence investment"
  }
];
