# UAE Smart Services Hub

An independent, bilingual (English/Arabic) UAE public-service navigation guide. It helps visitors discover official destinations and understand where to begin. It is not a government portal and does not process applications.

## Project structure

- `index.html` — accessible page structure and metadata
- `assets/css/styles.css` — responsive design, RTL support and reduced-motion handling
- `assets/js/services-data.js` — curated service catalogue
- `assets/js/app.js` — bilingual UI, search, filters, saved services and smart navigator
- `assets/favicon.svg` — project icon
- `manifest.webmanifest` — install metadata
- `tests/smoke.test.js` — automated source and catalogue checks

## Main features

- English and Arabic interface with right-to-left layout
- Service finder by need, emirate and audience
- Search across English/Arabic names, descriptions and keywords
- Category, emirate and audience filters
- Sort by name
- Save services locally in the current browser
- 28 official service destinations
- Safety guidance and UAE emergency contact numbers
- Responsive phone, tablet and desktop layouts
- No user accounts, backend, payments, document upload or collection of personal information
- External links open in a new tab with `noopener noreferrer`

## Publish on GitHub Pages

1. Download and keep a backup of your current repository.
2. Replace the repository contents with the contents of this project ZIP (the `index.html` must be at the published root).
3. Commit the changes to the branch and folder configured in **Settings → Pages**.
4. Wait for the Pages deployment to finish.
5. Test the live site on a phone and desktop, in English and Arabic.

The existing GitHub Pages URL can remain unchanged if the repository name and Pages configuration remain unchanged.

## Local testing

Requirements: Node.js 18+.

Run:

```bash
node --check assets/js/app.js
node --check assets/js/services-data.js
node --test tests/smoke.test.js
```

For a local browser preview, serve this directory with a static server (for example `python -m http.server 8000`) and open `http://localhost:8000`. Avoid opening `index.html` directly because local browser security may restrict assets.

## Accuracy, limitations and maintenance

- Service links are official starting points, not a guarantee that a particular transaction is available through that exact page.
- Government websites, service routes, fees, rules and eligibility can change. Confirm current information on the responsible authority's website.
- Some emirate-specific services vary by address, visa type, employer or other circumstances. The navigator does not make legal or eligibility decisions.
- Emergency numbers are shown for reference. For urgent situations, contact emergency services directly.
- Saved services use browser `localStorage` and do not sync across devices.
- The project does not currently use a backend, analytics, login or live government API.
- Review all service destinations periodically and update the catalogue when authorities change their domains or navigation.

## Design and accessibility

The interface uses semantic landmarks, keyboard-accessible controls, visible focus indicators, live result announcements, accessible labels, reduced-motion preferences and responsive layouts. Arabic switches the document direction to RTL.

## Maintainer

Independent project by Priya Dharshan.  
Feedback: pdharshanwork@gmail.com
